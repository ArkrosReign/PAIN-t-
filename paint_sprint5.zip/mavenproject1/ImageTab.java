package com.mycompany.mavenproject1;

import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.ScrollPane;
import javafx.scene.image.ImageView;
import javafx.scene.layout.StackPane;

/**
 * Represents one image workspace in Joes' Pain(t).
 */
public class ImageTab {

    private final ImageView imageView;
    private final Canvas canvas;
    private final Canvas selectionOverlay;
    private final StackPane drawingArea;
    private final ScrollPane scrollPane;

    /** Creates a blank image workspace. */
    public ImageTab() {
        imageView = new ImageView();
        imageView.setMouseTransparent(true);

        canvas = new Canvas(800, 500);
        selectionOverlay = new Canvas(800, 500);
        selectionOverlay.setMouseTransparent(true);

        drawingArea = new StackPane();
        drawingArea.getChildren().addAll(
            imageView,
            canvas,
            selectionOverlay
        );

        canvas.toFront();
        selectionOverlay.toFront();

        scrollPane = new ScrollPane();
        scrollPane.setContent(drawingArea);
        scrollPane.setPannable(true);
    }

    public Canvas getCanvas() {
        return canvas;
    }

    public GraphicsContext getGraphicsContext() {
        return canvas.getGraphicsContext2D();
    }

    public Canvas getSelectionOverlay() {
        return selectionOverlay;
    }

    public ImageView getImageView() {
        return imageView;
    }

    public StackPane getDrawingArea() {
        return drawingArea;
    }

    public ScrollPane getScrollPane() {
        return scrollPane;
    }
}
